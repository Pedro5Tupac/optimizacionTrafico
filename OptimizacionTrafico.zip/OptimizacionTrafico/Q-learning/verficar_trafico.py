import pyshark
import os

def analizar_pcap(ruta_pcap, tshark_path=None):
    print(f"\nAnalizando archivo: {ruta_pcap}")
    cap = pyshark.FileCapture(ruta_pcap, keep_packets=False, tshark_path=tshark_path)

    total = 0
    udp = 0
    tcp = 0
    otros = 0
    ips_origen = set()
    ips_destino = set()

    for pkt in cap:
        total += 1
        try:
            if hasattr(pkt, 'ip'):
                ips_origen.add(pkt.ip.src)
                ips_destino.add(pkt.ip.dst)

            if 'UDP' in pkt:
                udp += 1
            elif 'TCP' in pkt:
                tcp += 1
            else:
                otros += 1
        except AttributeError:
            continue

    cap.close()

    print(f"Total de paquetes: {total}")
    print(f"UDP: {udp}, TCP: {tcp}, Otros: {otros}")
    print(f"IPs origen únicas: {sorted(ips_origen)}")
    print(f"IPs destino únicas: {sorted(ips_destino)}")

if __name__ == "__main__":
    tshark_path = 'D:/Wireshark/tshark.exe'  # Ajusta si es necesario
    carpeta = r"C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset"
    archivos = ["router1.pcap", "router2.pcap", "router3.pcap", "router4.pcap"]

    for archivo in archivos:
        ruta = os.path.join(carpeta, archivo)
        if os.path.exists(ruta):
            analizar_pcap(ruta, tshark_path=tshark_path)
        else:
            print(f"Archivo no encontrado: {ruta}")
