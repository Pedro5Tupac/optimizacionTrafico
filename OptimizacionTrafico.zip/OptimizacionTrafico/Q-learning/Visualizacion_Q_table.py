import pickle
import numpy as np

# Cargar la Q-table
with open("Q_table.pkl", "rb") as f:
    Q = pickle.load(f)

print(f" Total de estados en Q-table: {len(Q)}")

# Revisar consistencia de acciones y valores Q
all_q_values = []
num_actions_per_state = []

for estado, acciones_q in Q.items():
    valores_q = list(acciones_q.values())
    all_q_values.extend(valores_q)
    num_actions_per_state.append(len(acciones_q))

q_array = np.array(all_q_values)

print(f" Acciones por estado (promedio): {np.mean(num_actions_per_state):.2f}")
print(f" Q-valores: min={q_array.min():.2f}, max={q_array.max():.2f}, promedio={q_array.mean():.2f}")
print(f" Porcentaje de valores Q iguales a 0: {np.sum(q_array == 0) / len(q_array) * 100:.2f}%")

# Mostrar un estado aleatorio con sus mejores acciones
import random
estado_muestra = random.choice(list(Q.keys()))
mejores_acciones = sorted(Q[estado_muestra].items(), key=lambda x: x[1], reverse=True)[:5]

print("\n Estado ejemplo (uso_bytes_por_enlace):", estado_muestra)
print(" Mejores acciones (acción -> Q-valor):")
for accion, valor in mejores_acciones:
    print(f"  {accion} -> {valor:.2f}")
