import pickle
import pyshark
import math
import itertools
import os
from collections import defaultdict

# ----------- Paso 1: Preprocesar PCAP individual -------------
def preprocesar_pcap_con_tiempos(cap, routers, enlaces, ventana_segundos=0.5):
    def enlace_key(ip1, ip2):
        return tuple(sorted([ip1, ip2]))

    current_window = None
    enlace_bytes = defaultdict(int)
    enlace_paquetes_udp = defaultdict(int)
    paquetes_fuera_udp = 0
    estados = []

    print(f"Routers: {routers}")
    print(f"Enlaces: {enlaces}")

    for pkt in cap:
        try:
            ts = float(pkt.sniff_timestamp)
            window_idx = math.floor(ts / ventana_segundos)

            if current_window is None:
                current_window = window_idx

            if window_idx != current_window:
                print(f"\n=== Ventana {current_window} finalizada ===")
                print(f"Uso de bytes por enlace: {[enlace_bytes[e] for e in enlaces]}")
                print(f"Paquetes UDP por enlace: {[enlace_paquetes_udp[e] for e in enlaces]}")
                print(f"Paquetes fuera UDP: {paquetes_fuera_udp}")

                estado = {
                    'window_idx': current_window,
                    'uso_bytes_por_enlace': [enlace_bytes[e] for e in enlaces],
                    'paquetes_udp_por_enlace': [enlace_paquetes_udp[e] for e in enlaces],
                    'paquetes_fuera_udp': paquetes_fuera_udp
                }
                estados.append(estado)

                # Reset para nueva ventana
                enlace_bytes = defaultdict(int)
                enlace_paquetes_udp = defaultdict(int)
                paquetes_fuera_udp = 0
                current_window = window_idx

            ip_src = pkt.ip.src
            ip_dst = pkt.ip.dst
            if ip_src not in routers or ip_dst not in routers:
                # Paquete descartado por IP no en routers
                continue

            key = enlace_key(ip_src, ip_dst)
            if key not in enlaces:
                # Paquete descartado por enlace no definido
                continue

            pkt_len = int(pkt.length)

            if 'UDP' in pkt:
                enlace_bytes[key] += pkt_len
                enlace_paquetes_udp[key] += 1
                print(f"Ventana {window_idx} - Enlace {key} - Paquete UDP, longitud {pkt_len}, timestamp {ts}")
            else:
                paquetes_fuera_udp += 1
                print(f"Ventana {window_idx} - Paquete no UDP, timestamp {ts}")

        except AttributeError:
            # Paquete sin campos esperados, ignorar
            continue

    # Última ventana
    if enlace_bytes or paquetes_fuera_udp:
        print(f"\n=== Última ventana {current_window} finalizada ===")
        print(f"Uso de bytes por enlace: {[enlace_bytes[e] for e in enlaces]}")
        print(f"Paquetes UDP por enlace: {[enlace_paquetes_udp[e] for e in enlaces]}")
        print(f"Paquetes fuera UDP: {paquetes_fuera_udp}")

        estado = {
            'window_idx': current_window,
            'uso_bytes_por_enlace': [enlace_bytes[e] for e in enlaces],
            'paquetes_udp_por_enlace': [enlace_paquetes_udp[e] for e in enlaces],
            'paquetes_fuera_udp': paquetes_fuera_udp
        }
        estados.append(estado)

    return estados, enlaces

# ----------- Paso 2: Fusionar estados por ventana ----------------
def fusionar_estados_por_ventana(lista_estados_routers):
    estados_por_ventana = defaultdict(list)

    for estados in lista_estados_routers:
        for estado in estados:
            idx = estado['window_idx']
            estados_por_ventana[idx].append(estado)

    estados_globales = []
    for idx in sorted(estados_por_ventana.keys()):
        estados_en_ventana = estados_por_ventana[idx]

        uso_bytes_sum = None
        paquetes_udp_sum = None
        paquetes_fuera_udp_sum = 0

        for estado in estados_en_ventana:
            if uso_bytes_sum is None:
                uso_bytes_sum = estado['uso_bytes_por_enlace'][:]
                paquetes_udp_sum = estado['paquetes_udp_por_enlace'][:]
            else:
                uso_bytes_sum = [x + y for x, y in zip(uso_bytes_sum, estado['uso_bytes_por_enlace'])]
                paquetes_udp_sum = [x + y for x, y in zip(paquetes_udp_sum, estado['paquetes_udp_por_enlace'])]

            paquetes_fuera_udp_sum += estado['paquetes_fuera_udp']

        estado_global = {
            'window_idx': idx,
            'uso_bytes_por_enlace': uso_bytes_sum,
            'paquetes_udp_por_enlace': paquetes_udp_sum,
            'paquetes_fuera_udp': paquetes_fuera_udp_sum
        }
        estados_globales.append(estado_global)

    return estados_globales

# ----------- Paso 3: Generar espacio de acciones ----------------
def generar_acciones(enlaces):
    acciones = [(0,)]  # Acción 0: no hacer nada
    for origen, destino in itertools.permutations(range(len(enlaces)), 2):
        acciones.append((origen, destino))
    return acciones

def main(return_data=False):
    tshark_path = 'D:/Wireshark/tshark.exe'
    
    # Define enlaces reales solo entre routers conectados:
    enlaces_reales = [
        ('10.0.0.1', '10.0.0.22'),
        ('10.0.0.13', '10.0.0.25'),
        ('10.0.0.17', '10.0.0.49'),
        ('10.0.0.29', '10.0.0.49'),
        ('10.0.0.41', '10.0.0.61'),
        ('10.0.0.57', '10.0.0.61')
    ]
    enlaces_reales = [tuple(sorted(e)) for e in enlaces_reales]

    # Crear la lista de routers automáticamente a partir de los enlaces
    routers = sorted(set(itertools.chain.from_iterable(enlaces_reales)))

    carpeta_pcap = r'C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset'

    archivos_pcap = ['router1.pcap', 'router2.pcap', 'router3.pcap', 'router4.pcap']
    rutas_pcap = [os.path.join(carpeta_pcap, f) for f in archivos_pcap]

    print("Verificando existencia de archivos PCAP:")
    for ruta in rutas_pcap:
        print(f"{ruta}: {os.path.exists(ruta)}")

    print("\nPreprocesando archivos PCAP...")
    estados_routers = []
    enlaces = enlaces_reales  # ahora usamos solo enlaces reales

    for archivo in rutas_pcap:
        if not os.path.exists(archivo):
            print(f"Archivo no encontrado: {archivo}")
            continue

        cap = pyshark.FileCapture(archivo, keep_packets=False, tshark_path=tshark_path)
        estados, _ = preprocesar_pcap_con_tiempos(cap, routers, enlaces, ventana_segundos=0.5)
        estados_routers.append(estados)
        print(f"{archivo} procesado: {len(estados)} ventanas.")

    print("\nFusionando estados por ventana...")
    estados_globales = fusionar_estados_por_ventana(estados_routers)
    print(f"Total de ventanas fusionadas: {len(estados_globales)}")

    print("\nGenerando acciones posibles...")
    acciones = generar_acciones(enlaces)
    print(f"Acciones posibles: {len(acciones)}")
    print("Ejemplos:", acciones[:5])

    print("\nTodo listo para entrenamiento de Q-learning.")
    with open('estados_globales.pkl', 'wb') as f:
        pickle.dump(estados_globales, f)

    with open('acciones.pkl', 'wb') as f:
        pickle.dump(acciones, f)
    if return_data:
        return estados_globales, acciones

if __name__ == "__main__":
    main()
