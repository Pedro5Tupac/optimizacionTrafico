import pyshark
import os
from collections import defaultdict

def detectar_routers_y_enlaces(pcap_files, tshark_path=None):
    ip_set = set()
    enlaces_reales = set()

    def normalizar_enlace(ip1, ip2):
        return tuple(sorted([ip1, ip2]))

    for archivo in pcap_files:
        print(f"Procesando: {archivo}")
        cap = pyshark.FileCapture(archivo, keep_packets=False, tshark_path=tshark_path)

        for pkt in cap:
            try:
                ip_src = pkt.ip.src
                ip_dst = pkt.ip.dst

                ip_set.add(ip_src)
                ip_set.add(ip_dst)

                enlace = normalizar_enlace(ip_src, ip_dst)
                enlaces_reales.add(enlace)
            except AttributeError:
                continue  # No es un paquete IP

        cap.close()

    routers = sorted(ip_set)
    enlaces = sorted(enlaces_reales)
    return routers, enlaces


def main():
    tshark_path = 'D:/Wireshark/tshark.exe'  # Cambia si es necesario

    carpeta_pcap = r'C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset'
    archivos_pcap = ['router1.pcap', 'router2.pcap', 'router3.pcap', 'router4.pcap']
    rutas_pcap = [os.path.join(carpeta_pcap, f) for f in archivos_pcap]

    routers, enlaces_reales = detectar_routers_y_enlaces(rutas_pcap, tshark_path)

    print("\n IPs detectadas (posibles routers):")
    for ip in routers:
        print(ip)

    print("\n Enlaces reales detectados:")
    for e in enlaces_reales:
        print(e)

    # Opcional: guardar para uso posterior
    with open('routers_detectados.txt', 'w') as f:
        for ip in routers:
            f.write(f"{ip}\n")

    with open('enlaces_reales_detectados.txt', 'w') as f:
        for e in enlaces_reales:
            f.write(f"{e[0]} {e[1]}\n")

    # También los puedes exportar en formato de Python
    print("\n Lista de routers (Python):")
    print("routers = [")
    for ip in routers:
        print(f"    '{ip}',")
    print("]")

    print("\n Lista de enlaces (Python):")
    print("enlaces = [")
    for e in enlaces_reales:
        print(f"    ('{e[0]}', '{e[1]}'),")
    print("]")

if __name__ == "__main__":
    main()
