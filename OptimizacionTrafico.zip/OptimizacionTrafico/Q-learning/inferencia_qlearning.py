import pickle

# Cargar la Q-table previamente guardada
with open('q_table.pkl', 'rb') as f:
    q_table = pickle.load(f)

# Función para seleccionar la mejor acción en un estado
def seleccionar_mejor_accion(estado, q_table):
    if estado not in q_table:
        print("Estado no encontrado en Q-table. Seleccionando acción por defecto.")
        return (0,)  # Acción por defecto
    return max(q_table[estado], key=q_table[estado].get)

# Ejemplo de uso con un nuevo estado (simulado aquí)
estado_actual = (10, 200, 5, 0, 0, 50, 1, 0, 0, 3, 400, 2)  # Reemplaza por un estado real
accion = seleccionar_mejor_accion(estado_actual, q_table)

print("Mejor acción para el estado actual:", accion)
