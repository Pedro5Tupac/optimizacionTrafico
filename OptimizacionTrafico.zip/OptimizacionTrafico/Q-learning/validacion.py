import pickle
import numpy as np
from preprocesamiento2 import main as cargar_datos

# Parámetros
UMBRAL_CONGESTION = 4000
QTABLE_PATH = 'Q_table.pkl'
ANCHO_BANDA = 10000  # bytes por ventana (latencia)

# === OPCIONAL: Reducción del espacio de estados ===
def agrupar_estado(uso_bytes, bin_size=1000):
    return tuple(int(x / bin_size) for x in uso_bytes)

def cargar_qtable(ruta):
    with open(ruta, 'rb') as f:
        return pickle.load(f)

def elegir_mejor_accion(qtable, estado_clave):
    if estado_clave in qtable:
        return max(qtable[estado_clave], key=qtable[estado_clave].get)
    else:
        return (0,)  # Acción por defecto

def aplicar_accion(estado, accion):
    nuevo_uso = estado['uso_bytes_por_enlace'][:]
    if len(accion) == 2:
        origen, destino = accion
        mover = int(0.2 * nuevo_uso[origen])
        nuevo_uso[origen] -= mover
        nuevo_uso[destino] += mover
    return nuevo_uso

def evaluar_modelo(qtable, estados_globales, acciones):
    recompensas = []
    congestiones = 0
    uso_total_por_enlace = np.zeros(len(estados_globales[0]['uso_bytes_por_enlace']))
    acciones_previas = []
    cambios_de_ruta = 0
    latencias = []

    for estado in estados_globales:
        uso_actual = estado['uso_bytes_por_enlace']
        estado_clave = agrupar_estado(uso_actual)  # agrupar para generalizar

        accion = elegir_mejor_accion(qtable, estado_clave)

        # Detectar cambios de ruta
        if acciones_previas and accion != acciones_previas[-1]:
            cambios_de_ruta += 1
        acciones_previas.append(accion)

        nuevo_uso = aplicar_accion(estado, accion)
        uso_total_por_enlace += nuevo_uso

        congestiones += np.sum(np.array(nuevo_uso) > UMBRAL_CONGESTION)

        latencias.append(np.sum(np.array(nuevo_uso) / ANCHO_BANDA))

        recompensa = -np.sum(nuevo_uso)
        recompensa -= 1000 * np.sum(np.array(nuevo_uso) > UMBRAL_CONGESTION)
        recompensas.append(recompensa)

    recompensa_promedio = np.mean(recompensas)
    uso_promedio_por_enlace = uso_total_por_enlace / len(estados_globales)
    desviacion_uso = np.std(uso_total_por_enlace)
    latencia_promedio = np.mean(latencias)

    return {
        "recompensa_promedio": recompensa_promedio,
        "uso_promedio_por_enlace": uso_promedio_por_enlace,
        "congestiones": congestiones,
        "cambios_de_ruta": cambios_de_ruta,
        "desviacion_uso": desviacion_uso,
        "latencia_promedio": latencia_promedio
    }

def main():
    print("Cargando Q-table entrenada...")
    qtable = cargar_qtable(QTABLE_PATH)

    print("Cargando estados y enlaces...")
    estados_globales, acciones = cargar_datos(return_data=True)

    print("Evaluando modelo...")
    resultados = evaluar_modelo(qtable, estados_globales, acciones)

    print(f"\n Resultados de Evaluación:")
    print(f" Recompensa media: {resultados['recompensa_promedio']:.2f}")
    print(f" Uso promedio por enlace (bytes): {[int(x) for x in resultados['uso_promedio_por_enlace']]}")
    print(f" Total de enlaces congestionados: {resultados['congestiones']}")
    print(f" Desviación estándar del uso (bytes): {resultados['desviacion_uso']:.2f}")
    print(f" Cambios de ruta detectados: {resultados['cambios_de_ruta']}")
    print(f" Latencia promedio estimada: {resultados['latencia_promedio']:.2f} unidades")

if __name__ == "__main__":
    main()
