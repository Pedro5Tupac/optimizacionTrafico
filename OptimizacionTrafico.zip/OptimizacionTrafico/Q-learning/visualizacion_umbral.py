import pickle

# Carga el archivo
with open('estados_globales.pkl', 'rb') as f:
    estados_globales = pickle.load(f)

# Cantidad total de ventanas (registros)
print(f"Número total de estados guardados: {len(estados_globales)}")

# Mostrar estructura y ejemplo del primer elemento
primer_estado = estados_globales[0]
print("Claves del primer estado:", primer_estado.keys())

# Mostrar valor de 'uso_bytes_por_enlace' en el primer estado
uso_primer_estado = primer_estado.get('uso_bytes_por_enlace', None)
print("Uso de bytes por enlace en el primer estado:", uso_primer_estado)

# Si quieres ver el tipo y tamaño
if uso_primer_estado is not None:
    print("Tipo:", type(uso_primer_estado))
    try:
        print("Longitud o forma:", len(uso_primer_estado))
    except TypeError:
        print("No tiene longitud")
else:
    print("La clave 'uso_bytes_por_enlace' no existe o es None")
errores = 0
for i, estado in enumerate(estados_globales):
    uso = estado.get('uso_bytes_por_enlace', None)
    if uso is None:
        print(f"Estado {i} no tiene 'uso_bytes_por_enlace'")
        errores += 1
    elif not hasattr(uso, '__len__'):
        print(f"Estado {i} tiene 'uso_bytes_por_enlace' pero no es iterable: {uso}")
        errores += 1

print(f"Total de estados con problemas: {errores}")
import numpy as np

uso_bytes_por_enlace = [estado['uso_bytes_por_enlace'] for estado in estados_globales if estado.get('uso_bytes_por_enlace') is not None]
uso_array = np.array(uso_bytes_por_enlace)

print(f"Shape de uso_array: {uso_array.shape}")
print(f"Valores mínimos y máximos: {uso_array.min()}, {uso_array.max()}")
print(f"Primeros 5 valores para enlace 0:", uso_array[:5, 0])
