import random
import joblib  # Usamos joblib para guardar Q-table comprimida

# ----------------- FUNCIONES DE LÓGICA ------------------

def estado_a_clave(estado, paso=100):
    """Convierte el estado en una tupla discretizada para reducir combinaciones."""
    return tuple(x // paso for x in estado['uso_bytes_por_enlace'])

def calcular_recompensa(estado, estado_anterior=None):
    uso = estado['uso_bytes_por_enlace']
    max_uso = max(uso)
    recompensa = -max_uso  # Penalización base

    if estado_anterior:
        max_prev = max(estado_anterior['uso_bytes_por_enlace'])
        if max_uso < max_prev:
            recompensa += 100  # Bonificación si mejora
    return recompensa

def aplicar_accion(estado, accion):
    nuevo_uso = estado['uso_bytes_por_enlace'][:]

    if len(accion) == 2:
        origen, destino = accion
        mover = int(0.2 * nuevo_uso[origen])
        nuevo_uso[origen] -= mover
        nuevo_uso[destino] += mover

    nuevo_estado = estado.copy()
    nuevo_estado['uso_bytes_por_enlace'] = nuevo_uso
    recompensa = calcular_recompensa(nuevo_estado, estado)
    return nuevo_estado, recompensa

def elegir_accion(Q, estado_clave, acciones, epsilon):
    if random.random() < epsilon or estado_clave not in Q:
        return random.choice(acciones)
    return max(Q[estado_clave], key=Q[estado_clave].get)

# ----------------- ENTRENAMIENTO ------------------

def entrenar_qlearning(estados_globales, acciones, alpha=0.1, gamma=0.9, 
                       epsilon=1.0, epsilon_min=0.1, epsilon_decay=0.995, 
                       episodios=1000, max_pasos=10):
    
    Q = {}
    for ep in range(episodios):
        for estado_inicial in estados_globales:
            estado = estado_inicial.copy()

            for paso in range(max_pasos):
                clave = estado_a_clave(estado)

                if clave not in Q:
                    Q[clave] = {}

                accion = elegir_accion(Q, clave, acciones, epsilon)

                if accion not in Q[clave]:
                    Q[clave][accion] = 0

                nuevo_estado, recompensa = aplicar_accion(estado, accion)
                nueva_clave = estado_a_clave(nuevo_estado)

                if nueva_clave not in Q:
                    Q[nueva_clave] = {}

                max_Q_nuevo = max(Q[nueva_clave].values(), default=0)
                Q[clave][accion] += alpha * (recompensa + gamma * max_Q_nuevo - Q[clave][accion])
                estado = nuevo_estado

        epsilon = max(epsilon_min, epsilon * epsilon_decay)

        if ep % 100 == 0:
            print(f" Episodio {ep}/{episodios} - Epsilon: {epsilon:.4f}")

    return Q

# ----------------- MAIN ------------------

if __name__ == "__main__":
    import preprocesamiento2

    print("Cargando datos...")
    estados_globales, acciones = preprocesamiento2.main(return_data=True)

    print("Iniciando entrenamiento...")
    Q = entrenar_qlearning(estados_globales, acciones)

    print("Guardando Q-table comprimida...")
    joblib.dump(Q, "Q_table_compressed.pkl", compress=3)

    print("Entrenamiento finalizado. Q-table comprimida guardada.")
