import pyshark
import os

def extraer_ips_unicas(rutas_pcap, tshark_path=None):
    todas_ips_origen = set()
    todas_ips_destino = set()

    for ruta in rutas_pcap:
        if not os.path.exists(ruta):
            print(f"[!] Archivo no encontrado: {ruta}")
            continue

        print(f"\nAnalizando archivo: {ruta}")
        cap = pyshark.FileCapture(ruta, keep_packets=False, tshark_path=tshark_path)

        ips_origen = set()
        ips_destino = set()
        total = 0

        for pkt in cap:
            total += 1
            try:
                ip_src = pkt.ip.src
                ip_dst = pkt.ip.dst
                ips_origen.add(ip_src)
                ips_destino.add(ip_dst)
            except AttributeError:
                continue  # Saltar paquetes sin capa IP

        cap.close()

        print(f"Total de paquetes: {total}")
        print(f"IPs origen únicas: {sorted(ips_origen)}")
        print(f"IPs destino únicas: {sorted(ips_destino)}")

        todas_ips_origen.update(ips_origen)
        todas_ips_destino.update(ips_destino)

    # Conjunto total de IPs vistas
    todas = todas_ips_origen.union(todas_ips_destino)
    print("\n=== Resumen Global ===")
    print(f"IPs únicas totales (origen y destino): {sorted(todas)}")
    return sorted(todas)

# === Uso ===
carpeta = r'C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset'
archivos_pcap = ['router1.pcap', 'router2.pcap', 'router3.pcap', 'router4.pcap']
rutas = [os.path.join(carpeta, f) for f in archivos_pcap]

# Reemplaza esta ruta con la de tu instalación de tshark si es necesario
tshark_path = 'D:/Wireshark/tshark.exe'

ips_unicas = extraer_ips_unicas(rutas, tshark_path=tshark_path)

# Puedes usar `ips_unicas` para construir routers o enlaces
