import pyshark
import os
from collections import defaultdict

tshark_path = 'D:/Wireshark/tshark.exe'

routers = [
    '10.0.0.13', '10.0.0.17', '10.0.0.21',
    '10.0.0.14', '10.0.0.29', '10.0.0.41',
    '10.0.0.18', '10.0.0.30', '10.0.0.57',
    '10.0.0.22', '10.0.0.42', '10.0.0.58'
]

rutas_pcap = [
    r'C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset\router1.pcap',
    r'C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset\router2.pcap',
    r'C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset\router3.pcap',
    r'C:\Users\Pedro\Desktop\Algoritmos no supervisados\Q-learning\dataset\router4.pcap'
]

enlaces_observados = set()

for ruta in rutas_pcap:
    print(f"Analizando {ruta}")
    cap = pyshark.FileCapture(ruta, keep_packets=False, tshark_path=tshark_path)

    for pkt in cap:
        try:
            ip_src = pkt.ip.src
            ip_dst = pkt.ip.dst

            # RELAJAR condición: basta con que una IP esté en routers
            if ip_src in routers or ip_dst in routers:
                key = tuple(sorted([ip_src, ip_dst]))
                enlaces_observados.add(key)
        except AttributeError:
            continue

print("\n=== Enlaces reales detectados ===")
for e in sorted(enlaces_observados):
    print(e)
