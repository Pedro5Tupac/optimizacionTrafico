import pyshark
import math
import itertools
import os
from collections import defaultdict


# ----------- Paso 1: Preprocesar PCAP individual -------------
def preprocesar_pcap_con_tiempos(pcap_file, routers, ventana_segundos=1):
    cap = pyshark.FileCapture(pcap_file, keep_packets=False)

    enlaces = []
    for i in range(len(routers)):
        for j in range(i + 1, len(routers)):
            enlaces.append(tuple(sorted([routers[i], routers[j]])))

    def enlace_key(ip1, ip2):
        return tuple(sorted([ip1, ip2]))

    current_window = None
    enlace_bytes = defaultdict(int)
    enlace_paquetes_udp = defaultdict(int)
    paquetes_fuera_udp = 0
    estados = []

    for pkt in cap:
        try:
            ts = float(pkt.sniff_timestamp)
            window_idx = math.floor(ts / ventana_segundos)

            if current_window is None:
                current_window = window_idx

            if window_idx != current_window:
                estado = {
                    'window_idx': current_window,
                    'uso_bytes_por_enlace': [enlace_bytes[e] for e in enlaces],
                    'paquetes_udp_por_enlace': [enlace_paquetes_udp[e] for e in enlaces],
                    'paquetes_fuera_udp': paquetes_fuera_udp
                }
                estados.append(estado)

                # Reset para nueva ventana
                enlace_bytes = defaultdict(int)
                enlace_paquetes_udp = defaultdict(int)
                paquetes_fuera_udp = 0
                current_window = window_idx

            ip_src = pkt.ip.src
            ip_dst = pkt.ip.dst
            if ip_src not in routers or ip_dst not in routers:
                continue

            key = enlace_key(ip_src, ip_dst)
            pkt_len = int(pkt.length)

            if 'UDP' in pkt:
                enlace_bytes[key] += pkt_len
                enlace_paquetes_udp[key] += 1
            else:
                paquetes_fuera_udp += 1

        except AttributeError:
            continue

    # Última ventana
    if enlace_bytes or paquetes_fuera_udp:
        estado = {
            'window_idx': current_window,
            'uso_bytes_por_enlace': [enlace_bytes[e] for e in enlaces],
            'paquetes_udp_por_enlace': [enlace_paquetes_udp[e] for e in enlaces],
            'paquetes_fuera_udp': paquetes_fuera_udp
        }
        estados.append(estado)

    return estados, enlaces

# ----------- Paso 2: Fusionar estados por ventana ----------------
def fusionar_estados_por_ventana(lista_estados_routers):
    estados_por_ventana = defaultdict(list)

    for estados in lista_estados_routers:
        for estado in estados:
            idx = estado['window_idx']
            estados_por_ventana[idx].append(estado)

    estados_globales = []
    for idx in sorted(estados_por_ventana.keys()):
        estados_en_ventana = estados_por_ventana[idx]

        uso_bytes_sum = None
        paquetes_udp_sum = None
        paquetes_fuera_udp_sum = 0

        for estado in estados_en_ventana:
            if uso_bytes_sum is None:
                uso_bytes_sum = estado['uso_bytes_por_enlace'][:]
                paquetes_udp_sum = estado['paquetes_udp_por_enlace'][:]
            else:
                uso_bytes_sum = [x + y for x, y in zip(uso_bytes_sum, estado['uso_bytes_por_enlace'])]
                paquetes_udp_sum = [x + y for x, y in zip(paquetes_udp_sum, estado['paquetes_udp_por_enlace'])]

            paquetes_fuera_udp_sum += estado['paquetes_fuera_udp']

        estado_global = {
            'window_idx': idx,
            'uso_bytes_por_enlace': uso_bytes_sum,
            'paquetes_udp_por_enlace': paquetes_udp_sum,
            'paquetes_fuera_udp': paquetes_fuera_udp_sum
        }
        estados_globales.append(estado_global)

    return estados_globales

# ----------- Paso 3: Generar espacio de acciones ----------------
def generar_acciones(enlaces):
    acciones = [(0,)]  # Acción 0: no hacer nada
    for origen, destino in itertools.permutations(range(len(enlaces)), 2):
        acciones.append((origen, destino))
    return acciones

def main():
    
    tshark_path = 'D:/Wireshark/tshark.exe'
    
    routers = [
        # Router1
        '10.0.0.1', '10.0.0.9', '10.0.0.13', '10.0.0.17', '10.0.0.21',
        # Router2
        '10.0.0.25', '10.0.0.33', '10.0.0.14', '10.0.0.29', '10.0.0.41',
        # Router3
        '10.0.0.49', '10.0.0.45', '10.0.0.18', '10.0.0.30', '10.0.0.57',
        # Router4
        '10.0.0.61', '10.0.0.65', '10.0.0.22', '10.0.0.42', '10.0.0.58'
    ]
    carpeta_pcap = 'dataset'

    archivos_pcap = ['router1.pcap', 'router2.pcap', 'router3.pcap', 'router4.pcap']
    rutas_pcap = [os.path.join(carpeta_pcap, f) for f in archivos_pcap]

    print("Preprocesando archivos PCAP...")
    estados_routers = []
    enlaces = None

    for archivo in rutas_pcap:
        cap = pyshark.FileCapture(archivo, keep_packets=False, tshark_path=tshark_path)
        estados, enlaces = preprocesar_pcap_con_tiempos(cap, routers)
        estados_routers.append(estados)
        print(f"{archivo} procesado: {len(estados)} ventanas.")

    print("\nFusionando estados por ventana...")
    estados_globales = fusionar_estados_por_ventana(estados_routers)
    print(f"Total de ventanas fusionadas: {len(estados_globales)}")

    print("\nGenerando acciones posibles...")
    acciones = generar_acciones(enlaces)
    print(f"Acciones posibles: {len(acciones)}")
    print("Ejemplos:", acciones[:5])

    print("\nTodo listo para entrenamiento de Q-learning.")

if __name__ == "__main__":
    main()